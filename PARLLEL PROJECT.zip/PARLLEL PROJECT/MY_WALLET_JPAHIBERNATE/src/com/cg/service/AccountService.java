package com.cg.service;
import java.sql.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpa.entity.Account;
import com.cg.dao.*;
import com.cg.exception.InsuffecientFundException;

public class AccountService implements Gst,Transaction {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	
	EntityManager em=emf.createEntityManager();
	
	AccountDAO dao=new AccountDAOImpl();

	@Override
	public boolean withdraw(Long mb, double amount) throws InsuffecientFundException, SQLException {
		Account s4=em.find(Account.class,mb);
		double bal=s4.getAccount_Balance()-amount;
		
		return dao.updateAccount(mb,bal);
		
	}

	@Override
	public boolean deposite(Long mb, double amount) throws SQLException {
		Account s4=em.find(Account.class,mb);
		double bal=s4.getAccount_Balance()+amount;
		
		return dao.updateAccount(mb,bal);
	}

	

	@Override
	public double calculateTax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return amount*Gst.PCT_5;
	}

	@Override
	public boolean addAccount(Account ob) throws SQLException {
		// TODO Auto-generated method stub\
		
		return dao.addAccount(ob);
	}
	

	@Override
	public boolean deleteAccount(Long mb) throws SQLException {
		// TODO Auto-generated method stub
		return dao.deleteAccount(mb);
	}

	

	@Override
	public ConcurrentHashMap<Long, Account> getAllAccount() throws SQLException {
		// TODO Auto-generated method stub
		return dao.getAllAccount();
	}

	@Override
	public boolean updateAccount(Long mb,double amount) throws SQLException {
		// TODO Auto-generated method stub
		return dao.updateAccount(mb,amount);
	}

	@Override
	public boolean TransferMoney(Long from, Long to, double amount) throws InsuffecientFundException, SQLException {
		// TODO Auto-generated method stub
		return dao.TransferMoney(from, to, amount);
	}

	@Override
	public Account findAccount(Long mb) throws SQLException {
		// TODO Auto-generated method stub
		return dao.findAccount(mb);
	}

	
	
	
	
	

}
