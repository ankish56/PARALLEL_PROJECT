package com.cg.service;

import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.jpa.entity.Account;
import com.cg.exception.InsuffecientFundException;

public interface AccountOperation {
	
    public boolean addAccount(Account ob) throws SQLException;
	
	
	
	public boolean deleteAccount(Long mb) throws SQLException;
	
	public Account findAccount(Long mb) throws SQLException;
	
	public boolean updateAccount(Long mb,double amount) throws SQLException;
	
	
	public ConcurrentHashMap<Long,Account> getAllAccount() throws SQLException;
	public boolean TransferMoney(Long from, Long to,double amount) throws InsuffecientFundException, SQLException;



	
	

}
