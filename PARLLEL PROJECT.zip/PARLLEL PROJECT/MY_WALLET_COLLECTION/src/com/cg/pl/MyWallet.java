package com.cg.pl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.bean.*;
import com.cg.exception.InsuffecientFundException;
import com.cg.service.*;

public class MyWallet {

	public static void main(String[] args) throws IOException, InsuffecientFundException {
		// TODO Auto-generated method stub
		AccountService service=new AccountService();
		ConcurrentHashMap<Long,Account>accmap=new ConcurrentHashMap<Long,Account>();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String choice="";
		while(true) {
		System.out.println("Menu");
		System.out.println("=======================================");
		System.out.println("1 Create new Account");
		System.out.println("2 Print all Account");
		System.out.println("3 Withdraw");
		System.out.println("4 Deposite");
		System.out.println("5 Fund Transfer");
		System.out.println("6 Exit");
		System.out.println("========================================");
		System.out.println("Enter Your Choice");
		choice=br.readLine();

		
		switch(choice) {
		case"1": int id=0;
				long mb=0L;
				String ah="";
				double bal=0.0;
				//Accepting and validating input for account number.......................
				System.out.println("Enter Account No:-");
				while(true) 
				{
					String s_id=br.readLine();
					boolean ch1=Validator.validatedata(s_id, Validator.aidpattern);
					if(ch1==true)
					{
						try
						{
							id=Integer.parseInt(s_id);
							break;
						}
						catch(NumberFormatException e)
						{
							System.out.println("Account Number must be numeric. Re-Enter");
						}
					}
					else
					{
						System.out.println("Re Enter Account Number in 3 digits");
					}
				}//end of while.................
				//Accepting and validate input for mobile number
				System.out.println("Enter Mobile No:-");
				while(true) 
				{
					String s_mb=br.readLine();
					boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
					if(ch1==true)
					{
						try
						{
							mb=Long.parseLong(s_mb);
							break;
						}
						catch(NumberFormatException e)
						{
							System.out.println("Monile Number must be numeric. Re-Enter");
						}
					}
					else
					{
						System.out.println("Re Enter Mobile Number in 10 digits");
					}
				}//end of while for mobile
				//accepting and validating account holder
				System.out.println("Enter Account Holder Name:-");
				while(true) {
					String s_nm=br.readLine();
					boolean ch2=Validator.validatedata(s_nm,Validator.namepattern);
					if(ch2==true)
					{
						ah=s_nm;
						break;
					}
					else {
						System.out.println("Re-Enter Name. Name should be in formate of Ram Kumar");
					}
				}//holdernamw while end........
				
				
				//accepting and validating account balance
				System.out.println("Enter Balance:-");
				while(true) {
					String s_bal=br.readLine();
					boolean ch3=Validator.validatedata(s_bal, Validator.balancepattern);
					if(ch3==true)
					{
						try
						{
							bal=Double.parseDouble(s_bal);
							break;
						}
						catch(NumberFormatException e)
						{
							System.out.println("Invalid Amount please enter again");
						}
					}
					else
					{
						System.out.println("Re Enter Amount. Should not be less then 1000 and in formate 0000.00");
					}
				}
				
				
				
				Account ob=new Account(id,mb,ah,bal);
				
				//calling addAccount method..........
				boolean b= service.addAccount(ob);
				System.out.println("Account Created");
				
			break;
		case"2"://for displaying all account........
		
			
			
			ConcurrentHashMap<Long,Account>accamp=service.getAllAccount();
			Collection<Account> vc=accamp.values();
			List<Account>acclist=new ArrayList<Account>(vc);
			Collections.sort(acclist);
			for(Account o:acclist) {
				
				service.printStatement(o);
				
			}
			
			break;
		case"3"://for withdraw........
			
			System.out.println("Enter Account Mobil No from which you want to withdraw");
			String s_no=br.readLine();
			mb=Long.parseLong(s_no);
			 Account ob1=service.findAccount(mb);
			 System.out.println("===========================================");
			 System.out.println("Your current Balance:-"+ ob1.getBalance());
			 System.out.println("===========================================");
			System.out.println("Enter amount to withdraw");
			
			while(true){
				String s_amt=br.readLine();
				bal=Double.parseDouble(s_amt);
			 if(bal>0){
				  double bal1=0.0;
			 try {
				 bal1=service.withdraw(ob1, bal);
				 System.out.println("===========================================");
				 System.out.println("Your balance after withdraw"+bal1);
				 System.out.println("===========================================");
				 break;
			 }
			 catch (InsuffecientFundException e){
				 
				 System.out.println("Invalid Amount.Re Enter Amount.");
				// System.err.println(e.getMessage());
			 }
			 }else{
				 System.out.println("Invalid Amount.Re Enter Amount.");
			 }
			}
			break;
			
		case"4"://for deposite.........
			
			System.out.println("Enter Account Mobile No  to deposite");
			String s_no2=br.readLine();
			mb=Long.parseLong(s_no2);
			Account obb1=service.findAccount(mb);
			System.out.println("===========================================");
			System.out.println("Your current Balance:-"+ obb1.getBalance());
			System.out.println("===========================================");
			System.out.println("Enter amount to deposite");
			while(true){
				
			
			String s_amt1=br.readLine();
			 Account ob2=service.findAccount(mb);
			 
			 bal=Double.parseDouble(s_amt1);
			 if(bal>0){
				  double bal2=0.0;
			 bal2=service.deposite(ob2, bal);
			 System.out.println("===========================================");
				 System.out.println("Your balance after Deposite"+bal2);
				 System.out.println("===========================================");
				 break;
			 }else{
				 System.out.println("Invalid Amount.Re Enter Amount.");
			 }
			}
			break;
			
		case"5"://for fund transfer..........
			System.out.println("Enter mobile no  to transfer fund");
			String s_mb1=br.readLine();
			mb=Long.parseLong(s_mb1);
			Account obb3=service.findAccount(mb);
			System.out.println("===========================================");
			System.out.println("Your current Balance:-"+ obb3.getBalance());
			System.out.println("===========================================");
			System.out.println("Enter mobine in which you want to transfer");
			String s_mb2=br.readLine();
			long mb1=Long.parseLong(s_mb2);
			
			
			
			Account obb2=service.findAccount(mb1);
			
			System.out.println("Enter Amount");
			String s_bal3=br.readLine();
			bal=Double.parseDouble(s_bal3);
			double b1=0.0,b2=0.0;
			try {
				b1=service.withdraw(obb3, bal);
				System.out.println("===========================================");
				System.out.println("Your balance after transfer"+b1);
				System.out.println("===========================================");
				b2=service.deposite(obb2, bal);
			}
			catch(InsuffecientFundException e){
				System.err.println(e.getMessage());
			}
			
			
			break;
			
		
		
		
		
		case"6":System.out.println("Exiting Program");
				System.exit(0);
		    break;
		default:System.out.println("Invalid Choice");    
		}
		}
		
		//end of menu...........
		
		
		
		
		
	}

}
