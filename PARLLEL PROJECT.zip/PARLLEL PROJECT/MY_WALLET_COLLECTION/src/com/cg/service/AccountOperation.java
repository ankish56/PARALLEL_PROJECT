package com.cg.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.bean.Account;
import com.cg.exception.InsuffecientFundException;

public interface AccountOperation {
	
    public boolean addAccount(Account ob);
	
	
	
	public boolean deleteAccount(Account ob);
	
	public Account findAccount(Long Mobileno);
	
	public boolean updateAccount(Account ob);
	
	
	public ConcurrentHashMap<Long,Account> getAllAccount();
	public double TransferMoney(Account from, Account to,double amount) throws InsuffecientFundException;
	

}
